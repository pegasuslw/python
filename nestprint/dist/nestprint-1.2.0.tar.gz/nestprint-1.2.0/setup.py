#!/usr/bin/env python
# coding=utf-8

from distutils.core import setup

setup(
        name         =  'nestprint',
        version      =  '1.2.0',
        py_modules   =  ['nestprint'],
        author       =  'liuwei',
        author_email =  '285488389@qq.com',
        url          = 'http://www.headfirstlabs.com',
        description  = 'A simple printer of nested lists',
    )
