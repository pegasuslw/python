#!/usr/bin/env python
# coding=utf-8

from __future__ import print_function

def print_lol(the_list, level):
    for each_item in the_list:
        if (isinstance(each_item,list)):
            print_lol(each_item, level+1)
        else:
            for i in range(level):
                print("\t",end='')
            print(each_item)

#names =  ["liu","yu","xuan", ["liuwei","wangyuanyuan",["baba","mama"]]]

#print_lol(names,0)
